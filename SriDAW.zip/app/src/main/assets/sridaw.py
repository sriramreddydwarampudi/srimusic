from music21 import stream, note

def main():
    s = stream.Stream()
    s.append(note.Note("C4"))
    s.append(note.Note("E4"))
    s.append(note.Note("G4"))
    s.write('midi', fp='/sdcard/Download/triad.mid')
